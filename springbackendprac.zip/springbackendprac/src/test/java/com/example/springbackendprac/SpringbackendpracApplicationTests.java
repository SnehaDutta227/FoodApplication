package com.example.springbackendprac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbackendpracApplicationTests {

	@Test
	void contextLoads() {
	}

}
