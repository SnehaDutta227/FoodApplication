package com.example.springbackendprac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbackendpracApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbackendpracApplication.class, args);
	}

}
